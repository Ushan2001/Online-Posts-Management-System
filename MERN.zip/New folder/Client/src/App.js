import React, { Component } from 'react'
import {BrowserRouter, Route, Routes} from "react-router-dom"; 
import Home from './components/Home'
import CreatePost from './components/CreatePost'
import EditPost from './components/EditPost'
import PostDetails from './components/PostDetails'
import NavBar from './components/NavBar'
import LoginInterface from './components/LoginInterface';
import SignUpInterface from './components/SignUpInterface';




export default class App extends Component {
  render() {
    return (
    


        <BrowserRouter>
        <NavBar/>
        <Routes>
            
            <Route path="/home"  element={<Home/>}></Route>
            <Route path="/add" element={<CreatePost/>}></Route>
            <Route path="/edit/:id" element={<EditPost/>}></Route>
            <Route path="/post/:id" element={<PostDetails/>}></Route>
            <Route path="/" element={<LoginInterface/>}></Route>
            <Route path="/sign" element={<SignUpInterface/>}></Route>
            </Routes>  
        </BrowserRouter>
      
    )
  }
}
