import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

export default function LoginInterface() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post("http://localhost:8070/login", {
        username,
        password,
      });

      console.log(response.data);
      navigate("/home"); // Navigate to the home page
    } catch (err) {
      console.error("Error logging in:", err.message);
      alert("Error logging in:", err.message)
    }
  };

  

  return (


    <div className="container" style={{marginTop:"40px"}} >
        <h2>Loggin</h2>
        <br></br>

<form onSubmit={handleLogin}>
    
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">User Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
    placeholder="Enter User Name"
    pattern="[a-z]{1,15}"
	title="Username should only contain lowercase letters. e.g. john"
    value={username} 
    onChange={(e) => setUsername(e.target.value)}
    />
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1"
    placeholder="Enter Password"
    value={password} 
    onChange={(e) => setPassword(e.target.value)}
    />
  </div>
 
  <button type="submit" className="btn btn-primary" style={{marginTop:"15px"}}>
  <i className='far fa-check-square'></i>
  &nbsp;Login
  </button>&nbsp; &nbsp;
  <Link to={"/sign"}>Sign Up Page</Link>
</form>

      
    </div>
  );
}
